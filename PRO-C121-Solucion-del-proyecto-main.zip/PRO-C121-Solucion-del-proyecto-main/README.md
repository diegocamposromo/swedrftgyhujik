# PROC121-solucion-proyecto
Reconocimiento de gestos de mano.  
Python. MediaPipe.  
  
Gestos de me gusta y no me gusta.  
  
### Texto en inglés: PROJECT-SOLUTION-C121
solution for project C121
